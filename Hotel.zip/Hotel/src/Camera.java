import java.time.LocalDate;
public class Camera {
	private float prezzoMinimo;
	private float prezzoMassimo;
	private int numeroPostiLetto;
	private Cliente [] clienti = new Cliente [365];
	private LocalDate dataInizio;
	private LocalDate dataFine;
	private boolean stato; // true==libera flase==occupata
	
	public Camera(float prezzoMinimo, float prezzoMassimo, int numeroPostiLetto, Cliente[] clienti, boolean stato, LocalDate dataInizio, LocalDate dataFine) {
		super();
		this.prezzoMinimo = prezzoMinimo;
		this.prezzoMassimo = prezzoMassimo;
		this.numeroPostiLetto = numeroPostiLetto;
		this.clienti = clienti;
		this.stato = stato;
		this.dataInizio = dataInizio;
		this.dataFine = dataFine;
	}
	public LocalDate getDataInizio() {
		return dataInizio;
	}
	public void setDataInizio(LocalDate dataInizio) {
		this.dataInizio = dataInizio;
	}
	public LocalDate getDatafine() {
		return dataFine;
	}
	public void setDatafine(LocalDate datafine) {
		this.dataFine = datafine;
	}
	public float getPrezzoMinimo() {
		return prezzoMinimo;
	}
	public void setPrezzoMinimo(float prezzoMinimo) {
		this.prezzoMinimo = prezzoMinimo;
	}
	public float getPrezzoMassimo() {
		return prezzoMassimo;
	}
	public void setPrezzoMassimo(float prezzoMassimo) {
		this.prezzoMassimo = prezzoMassimo;
	}
	public int getNumeroPostiLetto() {
		return numeroPostiLetto;
	}
	public void setNumeroPostiLetto(int numeroPostiLetto) {
		this.numeroPostiLetto = numeroPostiLetto;
	}
	public Cliente[] getClienti() {
		return clienti;
	}
	public void setClienti(Cliente[] clienti) {
		this.clienti = clienti;
	}
	public boolean getStato() {
		return stato;
	}
	public void setStato(boolean stato) {
		this.stato = stato;
	}
	
}
