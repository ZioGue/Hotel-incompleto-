
public class Azienda extends Cliente{
	private String nome;
	private String cognome;
	private String numeroTelefono;
	private String nomeAzienda;
	private String partitaIva;
	private String indirizzoFatturazione;
	
	public Azienda(boolean tipo, String nome, String cognome, String numeroTelefono, String nomeAzienda, String partitaIva, String indirizzoFatturazione) {
		super(tipo);
		this.nomeAzienda = nomeAzienda;
		this.partitaIva = partitaIva;
		this.indirizzoFatturazione = indirizzoFatturazione;
		this.nome = nome;
		this.cognome = cognome;
		this.numeroTelefono = numeroTelefono;
	}

	public String getNomeAzienda() {
		return nomeAzienda;
	}

	public void setNomeAzienda(String nomeAzienda) {
		this.nomeAzienda = nomeAzienda;
	}

	public String getPartitaIva() {
		return partitaIva;
	}

	public void setPartitaIva(String partitaIva) {
		this.partitaIva = partitaIva;
	}

	public String getIndirizzoFatturazione() {
		return indirizzoFatturazione;
	}

	public void setIndirizzoFatturazione(String indirizzoFatturazione) {
		this.indirizzoFatturazione = indirizzoFatturazione;
	}
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}
}
