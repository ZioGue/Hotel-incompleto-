
public class Cliente {
	private boolean tipo; // true==private false==azienda

	public Cliente(boolean tipo) {
		super();
		this.tipo = tipo;
	}

	public boolean isTipo() {
		return tipo;
	}

	public void setTipo(boolean tipo) {
		this.tipo = tipo;
	}
	
}
