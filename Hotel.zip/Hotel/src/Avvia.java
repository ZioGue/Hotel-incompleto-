import java.util.Scanner;
import java.time.LocalDate;
public class Avvia {

	public static void main(String[] args) {
		Cliente c = null;
		ClientePrivato cp = null;
		Azienda a = null;
		Camera cam = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Menu");
		System.out.println("1) Inserisci cliente in una stanza e la data");
		System.out.println("2) Dato un periodo dire quali stanze sono libere");
		System.out.println("3) Dato un cliente dire in quale stanza di trova o si � trovato e per quale periodo");
		System.out.println("4) Data una stanza e una data dire se la stanza � occupata e, nel caso dire chi la occupa");
		System.out.println("5) Chiudere il programma");
		int menu = sc.nextInt();
		char tipo;
		String nome;
		String cognome;
		String numeroTelefono;
		String nomeAzienda;
		String partitaIva;
		String indirizzoFatturazione;
		int giorno;
		int mese;
		int anno;
		int giornoF;
		int meseF;
		int annoF;
		LocalDate dataInizio;
		LocalDate dataFine;
		boolean stato=true;
		sc.nextLine();
		do {
		switch(menu) {
		case 1:
			System.out.println("Inserire se il cliente � Privato o Aziendale");
			System.out.println("Inserisci P se Privato altrimenti A se Aziendale");
			tipo = sc.next().charAt(0);
			if(tipo == 'P') {
				c.setTipo(true);
				System.out.println("Inserisci il nome del cliente");
				nome = sc.nextLine();
				cp.setNome(nome);
				System.out.println("Inserisci il cognome del cliente");
				cognome = sc.nextLine();
				cp.setCognome(cognome);
				System.out.println("Inserici il numero di telefono del cliente");
				numeroTelefono = sc.nextLine();
				cp.setNumeroTelefono(numeroTelefono);	
				System.out.println("Inserisci la data di inizio");
				System.out.println("Giorno");
				giorno = sc.nextInt();
				System.out.println("Mese");
				mese = sc.nextInt();
				System.out.println("Anno");
				anno = sc.nextInt();
				dataInizio = LocalDate.of(anno, mese, giorno);
				cam.setDataInizio(dataInizio);
				System.out.println("Inserisci la data di fine");
				System.out.println("Giorno");
				giornoF = sc.nextInt();
				System.out.println("Mese");
				meseF = sc.nextInt();
				System.out.println("Anno");
				annoF = sc.nextInt();
				dataFine = LocalDate.of(annoF, meseF, giornoF);
				cam.setDatafine(dataFine);
			}
			else if(tipo == 'A') {
				c.setTipo(false);
				System.out.println("Inserisci il nome del cliente");
				nome = sc.nextLine();
				a.setNome(nome);
				System.out.println("Inserisci il cognome del cliente");
				cognome = sc.nextLine();
				a.setCognome(cognome);
				System.out.println("Inserici il numero di telefono del cliente");
				numeroTelefono = sc.nextLine();
				a.setNumeroTelefono(numeroTelefono);	
				System.out.println("Inserisci la data di inizio");
				System.out.println("Giorno");
				giorno = sc.nextInt();
				System.out.println("Mese");
				mese = sc.nextInt();
				System.out.println("Anno");
				anno = sc.nextInt();
				dataInizio = LocalDate.of(anno, mese, giorno);
				cam.setDataInizio(dataInizio);
				System.out.println("Inserisci la data di fine");
				System.out.println("Giorno");
				giornoF = sc.nextInt();
				System.out.println("Mese");
				meseF = sc.nextInt();
				System.out.println("Anno");
				annoF = sc.nextInt();
				dataFine = LocalDate.of(annoF, meseF, giornoF);
				cam.setDatafine(dataFine);
				System.out.println("Inserisi il nome dell'azienda del cliente");
				nomeAzienda = sc.nextLine();
				a.setNomeAzienda(nomeAzienda);
				System.out.println("Inserisci la Partita IVA");
				partitaIva = sc.nextLine();
				a.setPartitaIva(partitaIva);
				System.out.println("Inserisci l'indirizzo di fatturazione");
				indirizzoFatturazione = sc.nextLine();
				a.setIndirizzoFatturazione(indirizzoFatturazione);
			}
			else {System.out.println("Comando errato, riprova");}
			break;
		case 2: 
			break;
		case 3: 
			break;
		case 4:
			break;
		case 5:
			System.out.println("Chiusura del Programma");
			stato = false;
			break;
		
		}
		}while(stato==true);

	}

}
